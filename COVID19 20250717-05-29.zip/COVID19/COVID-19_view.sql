CREATE DATABASE IF NOT EXISTS dbron;
USE dbron;

-- 既存のビューがあれば削除
DROP VIEW IF EXISTS user_health_activity_today;

-- その日の体調記録とアクティビティの数を数えるビューの作成
CREATE OR REPLACE VIEW user_health_activity_today AS
SELECT 
    u.userID,
    COALESCE(ch.health_count, 0) AS check_health_count,
    COALESCE(ac.activity_count, 0) AS activity_count
FROM user u
LEFT JOIN (
    SELECT userID, COUNT(*) AS health_count
    FROM check_health
    WHERE delflag = 0
      AND input_date = DATE(CONVERT_TZ(NOW(), 'UTC', 'Asia/Tokyo'))
    GROUP BY userID
) ch ON u.userID = ch.userID
LEFT JOIN (
    SELECT userID, COUNT(*) AS activity_count
    FROM activity
    WHERE delflag = 0
      AND went_date = DATE(CONVERT_TZ(NOW(), 'UTC', 'Asia/Tokyo'))
    GROUP BY userID
) ac ON u.userID = ac.userID;

SELECT * FROM user_health_activity_today;

-- 体調管理とユーザーのビュー
DROP VIEW IF EXISTS check_health_user;

CREATE VIEW check_health_user AS
  SELECT 
    check_health.check_healthID AS check_healthID,
    check_health.userID AS userID,
    user.user_code AS user_code,
    user.l_name AS l_name,
    user.f_name AS f_name,
    check_health.input_date AS input_date,
    check_health.am_pm AS am_pm,
    check_health.body_temp AS body_temp,
    check_health.pain AS pain,
    check_health.washedout_feeling AS washedout_feeling,
    check_health.headache AS headache,
    check_health.sore_throat AS sore_throat,
    check_health.breathless AS breathless,
    check_health.cough AS cough,
    check_health.vomiting AS vomiting,
    check_health.diarrhea AS diarrhea,
    check_health.taste_disorder AS taste_disorder,
    check_health.olfactory_disorder AS olfactory_disorder,
    check_health.delflag AS delflag,
    check_health.lastupdate AS lastupdate
  FROM 
    check_health
  INNER JOIN 
    user ON check_health.userID = user.userID;

SELECT *
FROM check_health_user
;

-- 行動記録とユーザーのビュー
DROP VIEW IF EXISTS activity_user;

CREATE VIEW activity_user AS
  SELECT 
    activity.activityID AS activityID,
    activity.userID AS userID,
    user.user_code AS user_code,
    user.l_name AS l_name,
    user.f_name AS f_name,
    activity.went_date AS went_date,
    activity.went_time AS went_time,
    activity.return_time AS return_time,
    activity.location AS location,
    activity.move_method AS move_method,
    activity.departure AS departure,
    activity.arrival AS arrival,
    activity.comp_NY AS comp_NY,
    activity.comp_num AS comp_num,
    activity.sp_mention AS sp_mention,
    activity.delflag AS delflag,
    activity.lastupdate AS lastupdate
  FROM 
    activity
  INNER JOIN 
    user ON activity.userID = user.userID;

SELECT *
FROM activity_user
;

-- 出席停止とユーザーのビュー
DROP VIEW IF EXISTS suspension_user;

CREATE VIEW suspension_user AS
  SELECT 
    suspension.suspensionID AS suspensionID,
    suspension.userID AS userID,
    user.user_code AS user_code,
    user.l_name AS l_name,
    user.f_name AS f_name,
    suspension.susp_school AS susp_school,
    suspension.start_date AS start_date,
    suspension.end_date AS end_date,
    suspension.reason AS reason,
    suspension.institution_name AS institution_name,
    suspension.doctor_name AS doctor_name,
    suspension.status AS status,
    suspension.mention AS mention,
    suspension.delflag AS delflag,
    suspension.lastupdate AS lastupdate
  FROM 
    suspension
  INNER JOIN 
    user ON suspension.userID = user.userID;

SELECT *
FROM suspension_user
;

-- 個人情報を取得するビュー
DROP VIEW IF EXISTS user_userfrom_userpass;

CREATE VIEW user_userfrom_userpass AS
SELECT
    user.userID AS userID,
    user.affiliation AS affiliation,
    user.user_code AS user_code,
    user.l_name AS l_name,
    user.f_name AS f_name,
    user.l_name_kana AS l_name_kana,
    user.f_name_kana AS f_name_kana,
    user.gender AS gender,
    user.birthday AS birthday,
    user.e_mail AS e_mail,
    user_from.return_home AS return_home,
    user_from.post_num AS post_num,
    user_from.prefecture AS prefecture,
    user_from.city AS city,
    user_from.area AS area,
    user_from.phone AS phone,
    user_pass.user_name AS user_name,
    user_pass.password AS password
FROM
    user
INNER JOIN
    user_from ON user.userID = user_from.userID
INNER JOIN
    user_pass ON user.userID = user_pass.userID;

SELECT *
FROM user_userfrom_userpass
;

-- 体調記録と行動記録の未記載日数を取得するビュー
DROP VIEW IF EXISTS view_missing_all;
CREATE VIEW view_missing_all AS
SELECT
    u.userID,
    ch.last_health_date,
    act.last_activity_date,
    GREATEST(
      IFNULL(ch.last_health_date, '1900-01-01'),
      IFNULL(act.last_activity_date, '1900-01-01')
    ) AS last_input_date
FROM user u
LEFT JOIN (
    SELECT userID, MAX(input_date) AS last_health_date
    FROM check_health
    WHERE delflag = 0
    GROUP BY userID
) ch ON u.userID = ch.userID
LEFT JOIN (
    SELECT userID, MAX(went_date) AS last_activity_date
    FROM activity
    WHERE delflag = 0
    GROUP BY userID
) act ON u.userID = act.userID
WHERE
  (ch.last_health_date IS NULL OR DATEDIFF(CURDATE(), ch.last_health_date) >= 3)
  OR
  (act.last_activity_date IS NULL OR DATEDIFF(CURDATE(), act.last_activity_date) >= 3);
  
-- 体調記録と行動記録の未連絡日数を取得するビュー
DROP VIEW IF EXISTS view_missing_contact;
CREATE VIEW view_missing_contact AS
SELECT
    vma.userID,
    vma.last_health_date,
    vma.last_activity_date,
    vma.last_input_date,
    cl.last_contact_date
FROM view_missing_all vma
LEFT JOIN (
    SELECT userID, MAX(last_contact_date) AS last_contact_date
    FROM contact_log
    WHERE contacted_reason = 0
    GROUP BY userID
) cl ON vma.userID = cl.userID
WHERE
    cl.last_contact_date IS NULL
    OR cl.last_contact_date = '1900-01-01'
    OR DATEDIFF(CURDATE(), cl.last_contact_date) <= 3;
    
SELECT *
FROM view_missing_all
;

SELECT *
FROM view_missing_contact
;

-- 要注意者を取得するビュー
DROP VIEW IF EXISTS symptomatic_users;

CREATE VIEW symptomatic_users AS
SELECT 
    ch_latest.userID,
    u.user_code,
    u.l_name,
    u.f_name,
    u.e_mail AS email,
    uf.phone AS phone,
    ch_latest.input_date,
    ch_latest.body_temp,
    ch_latest.symptom_count
FROM
    (
        SELECT
            ch.userID,
            ch.input_date,
            ch.body_temp,
            (
                (ch.pain + 0) +
                (ch.washedout_feeling + 0) +
                (ch.headache + 0) +
                (ch.sore_throat + 0) +
                (ch.breathless + 0) +
                (ch.cough + 0) +
                (ch.vomiting + 0) +
                (ch.diarrhea + 0) +
                (ch.taste_disorder + 0) +
                (ch.olfactory_disorder + 0)
            ) AS symptom_count
        FROM check_health ch
        JOIN
        (
            SELECT userID, MAX(lastupdate) AS latest_update
            FROM check_health
            WHERE delflag = FALSE
            GROUP BY userID
        ) ch_max ON ch.userID = ch_max.userID AND ch.lastupdate = ch_max.latest_update
        WHERE ch.delflag = FALSE
    ) ch_latest
JOIN user u ON ch_latest.userID = u.userID AND u.delflag = FALSE
LEFT JOIN user_from uf ON u.userID = uf.userID AND uf.delflag = FALSE
WHERE
    ch_latest.body_temp >= 37.5
    OR ch_latest.symptom_count >= 5;


-- 未入力者用
-- 全ての未記載者（連絡済み含む）
DROP VIEW IF EXISTS view_missing_contact;
CREATE VIEW view_missing_contact AS
SELECT
    vma.userID,
    vma.last_health_date,
    vma.last_activity_date,
    vma.last_input_date,
    cl.last_contact_date
FROM view_missing_all vma
LEFT JOIN (
    SELECT userID, MAX(last_contact_date) AS last_contact_date
    FROM contact_log
    WHERE contacted_reason = 0
    GROUP BY userID
) cl ON vma.userID = cl.userID
WHERE
    -- 連絡なし、または連絡日が1900-01-01の場合（未連絡扱い）
    cl.last_contact_date IS NULL
    OR cl.last_contact_date = '1900-01-01'
    OR
    -- 連絡済みかつ連絡から3日以内
    DATEDIFF(CURDATE(), cl.last_contact_date) <= 3;

-- 要注意者用（未連絡または連絡から3日以内）
-- 最新1件のみ
DROP VIEW IF EXISTS view_symptomatic_contact;

CREATE VIEW view_symptomatic_contact AS
SELECT
  ch.userID,
  ch.check_healthID,
  ch.input_date,
  ch.body_temp,
  (
    (ch.pain+0) +
    (ch.washedout_feeling+0) +
    (ch.headache+0) +
    (ch.sore_throat+0) +
    (ch.breathless+0) +
    (ch.cough+0) +
    (ch.vomiting+0) +
    (ch.diarrhea+0) +
    (ch.taste_disorder+0) +
    (ch.olfactory_disorder+0)
  ) AS symptom_count,
  cl.last_contact_date
FROM check_health ch
JOIN (
  -- userIDごとに最新のinput_dateを取得
  SELECT userID, MAX(input_date) AS max_input_date
  FROM check_health
  WHERE delflag = 0
  GROUP BY userID
) latest_date ON ch.userID = latest_date.userID AND ch.input_date = latest_date.max_input_date
JOIN (
  -- userIDごとに最新のcheck_healthIDを取得（同じ最新日付で複数ある場合の対策）
  SELECT userID, MAX(check_healthID) AS max_check_healthID
  FROM check_health
  WHERE delflag = 0
  GROUP BY userID
) latest_id ON ch.userID = latest_id.userID AND ch.check_healthID = latest_id.max_check_healthID
LEFT JOIN contact_log cl ON ch.userID = cl.userID AND cl.contacted_reason = 1
WHERE
  (ch.body_temp >= 37.5 OR
   ((ch.pain+0) + (ch.washedout_feeling+0) + (ch.headache+0) + (ch.sore_throat+0) + (ch.breathless+0) +
    (ch.cough+0) + (ch.vomiting+0) + (ch.diarrhea+0) + (ch.taste_disorder+0) + (ch.olfactory_disorder+0)) >= 5)
  AND (
    cl.contact_logID IS NULL
    OR cl.last_contact_date = '1900-01-01'
    OR DATEDIFF(CURDATE(), cl.last_contact_date) <= 3
  );
    
-- 出校停止者用
CREATE OR REPLACE VIEW view_suspension_contact AS
SELECT
    NULL AS check_healthID,
    s.suspensionID,
    NULL AS activityID,
    s.userID,
    2 AS contacted_reason,
    s.start_date AS input_date,
    cl.last_contact_date
FROM suspension s
LEFT JOIN contact_log cl
    ON s.userID = cl.userID AND cl.contacted_reason = 2
WHERE s.start_date <= CURDATE()
  AND s.end_date >= CURDATE();
