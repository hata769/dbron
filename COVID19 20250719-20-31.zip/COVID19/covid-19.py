# covid19.py 
# FlaskモジュールでDBの操作
import re
from ssl import MemoryBIO
from MyDatabase import my_open , my_query , my_close
import pandas as pd

from flask import Flask, request, render_template, redirect, url_for, session, flash
import mysql.connector
from flask_bcrypt import Bcrypt
from datetime import datetime, timedelta, date
import mysql.connector
import os

# パスワードのハッシュ化
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

#user_passからpasswordを読み込むための関数（個人情報部分）
import csv

# この関数を使って、userID からハッシュ化される前のパスワードを取得
def get_plain_password_from_csv(user_name, csv_path="user_pass.csv"):
    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            if row["user_name"] == user_name:
                return row["password"]
    return None

# 関数のインポート
from today_input import df_user_health_activity_today #今日の活動件数を検索する関数（引数：userID）

app = Flask(__name__, static_folder="static")
# セッション情報の暗号化や署名に使う
app.secret_key = 'covid-19-test'# 後々環境変数から読み込むかも
app.permanent_session_lifetime = timedelta(minutes=30)
bcrypt = Bcrypt(app)

# ファイルアップロード
bcrypt = Bcrypt()

UPLOAD_FOLDER = '/path/to/uploaded/csv'  # 適切に設定
ALLOWED_EXTENSIONS = {'csv'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def insert_missing_entry_contacts():
    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    # 3日以上未記載ユーザーを取得
    cur.execute("""
        SELECT 
            userID,
            GREATEST(
                IFNULL(last_health_date, DATE('1900-01-01')),
                IFNULL(last_activity_date, DATE('1900-01-01'))
            ) AS last_input_date
        FROM missing_entry_user
        WHERE DATEDIFF(CURDATE(), GREATEST(
            IFNULL(last_health_date, DATE('1900-01-01')),
            IFNULL(last_activity_date, DATE('1900-01-01'))
        )) >= 3
    """)
    users = cur.fetchall()

    for user in users:
        cur.execute("""
            INSERT IGNORE INTO contact_log (userID, contacted_reason, last_contact_date, lastupdate)
            VALUES (%s, %s, CURDATE(), NOW())
        """, (user["userID"], 0))  # 0 = 未記載者

    conn.commit()
    cur.close()
    conn.close()

# MySQL 接続情報
dsn = {
    'host': '172.30.0.10',
    'port': '3306',
    'user': 'root',
    'password': '1234',
    'database': 'dbron'
}

# ログインページ
@app.route("/login", methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        # ユーザー名とパスワードの受け取り
        username = request.form['username']
        password = request.form['password']

        # ユーザー名の照合
        try:
            conn = mysql.connector.connect(**dsn)
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM user_pass WHERE user_name = %s", (username,))
            user = cursor.fetchone()
            cursor.close()
            conn.close()
        except Exception as e:
            return f"DB接続エラー: {e}"

        if user:
            # パスワードチェック
            if bcrypt.check_password_hash(user['password'], password):
                session.permanent = True
                session['username'] = username
                session['permission'] = user['permission']
                session['userID'] = user['userID']  # ← 追加
                return redirect(url_for('top'))
            else:
                error = "ユーザー名またはパスワードが正しくありません"
        else:
            error = "ユーザー名またはパスワードが正しくありません"

    return render_template("covid-19-login.html", error=error)

# ログアウト
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for('login'))

# トップページ
@app.route("/")
def top():
    # ログインしていなければログインページへ
    if "username" not in session:
        return redirect(url_for('login'))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    today = date.today()
    user_id = session["userID"]
    
    # 氏名の取得
    cur.execute("SELECT l_name, f_name FROM user WHERE userID = %s", (user_id,))
    name_result = cur.fetchone()

    # 本日の記録件数取得
    df = df_user_health_activity_today(user_id)
    if not df.empty:
        health_count = int(df.iloc[0]["check_health_count"])
        activity_count = int(df.iloc[0]["activity_count"])
    else:
        health_count = 0
        activity_count = 0

    # 初期値
    symptomatic_count = 0
    missing_count = 0
    uncontacted_symptomatic = 0
    uncontacted_missing = 0

    if session.get("permission") == 1:
        # 要注意者リスト取得
        cur.execute("SELECT * FROM symptomatic_users")
        symptomatic_users = cur.fetchall()

        # contact_logから連絡済み情報を取得
        cur.execute("SELECT userID, contacted_reason, last_contact_date FROM contact_log")
        rows = cur.fetchall()

        # contacted_reasonごとに連絡済みユーザーIDを管理する辞書
        contacted_dict = {
            0: set(),  # 未記載者
            1: set(),  # 要注意者
            2: set()   # 出校停止者
        }
        for row in rows:
            uid = row["userID"]
            reason = row["contacted_reason"]
            contacted_dict[reason].add(uid)

        # 要注意者未連絡数カウント
        for user in symptomatic_users:
            symptomatic_count += 1
            if user["userID"] not in contacted_dict[1]:
                uncontacted_symptomatic += 1

        # 未記載者リスト取得
        cur.execute("SELECT * FROM missing_entry_user")
        all_missing = cur.fetchall()

        for row in all_missing:
            health_gap = (today - row["last_health_date"]).days if row["last_health_date"] else 999
            activity_gap = (today - row["last_activity_date"]).days if row["last_activity_date"] else 999

            if health_gap >= 3 or activity_gap >= 3:
                missing_count += 1
                if row["userID"] not in contacted_dict[0]:
                    uncontacted_missing += 1

    cur.close()
    conn.close()

    return render_template(
        "covid-19-top.html",
        username=session["username"],
        permission=session["permission"],
        l_name=name_result['l_name'],
        f_name=name_result['f_name'],
        title="Covid-19管理システムトップ",
        health_count=health_count,
        activity_count=activity_count,
        symptomatic_count=symptomatic_count,
        missing_count=missing_count,
        uncontacted_symptomatic=uncontacted_symptomatic,
        uncontacted_missing=uncontacted_missing
    )

# 体調記録
@app.route("/check_health1")
def check_health1():
    # ログインしていなければログインページへ
    if "username" not in session:
        return redirect(url_for("login"))
    
    # 体調観察記入フォームに移行
    return render_template("covid-19-check_health1.html",
        title = "体調観察記録"
    )

# 体調記録を受け取り、check_healthテーブルに保存
@app.route("/check_health2", methods=["POST"])
def check_health2():
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = mysql.connector.connect(**dsn)
        cur = conn.cursor()

        # userID 取得
        cur.execute("SELECT userID FROM user_pass WHERE user_name = %s", (session["username"],))
        result = cur.fetchone()
        if not result:
            return "ユーザーが見つかりません"
        user_id = result[0]

        # フォームデータ取得
        input_date = request.form["input_date"]
        am_pm = int(request.form["am_pm"])
        body_temp = float(request.form["body_temp"])
        pain = "pain" in request.form
        washedout_feeling = "washedout_feeling" in request.form
        headache = "headache" in request.form
        sore_throat = "sore_throat" in request.form
        breathless = "breathless" in request.form
        cough = "cough" in request.form
        vomiting = "vomiting" in request.form
        diarrhea = "diarrhea" in request.form
        taste_disorder = "taste_disorder" in request.form
        olfactory_disorder = "olfactory_disorder" in request.form
        dt_now = datetime.now()

        # check_health登録
        insert_sql = """
            INSERT INTO check_health (
                userID, input_date, am_pm, body_temp,
                pain, washedout_feeling, headache, sore_throat,
                breathless, cough, vomiting, diarrhea,
                taste_disorder, olfactory_disorder, lastupdate
            ) VALUES (
                %s, %s, %s, %s,
                %s, %s, %s, %s,
                %s, %s, %s, %s,
                %s, %s, %s
            )
        """
        cur.execute(insert_sql, (
            user_id, input_date, am_pm, body_temp,
            int(pain), int(washedout_feeling), int(headache), int(sore_throat),
            int(breathless), int(cough), int(vomiting), int(diarrhea),
            int(taste_disorder), int(olfactory_disorder), dt_now
        ))
        conn.commit()
        check_health_id = cur.lastrowid

        # 症状カウント計算
        symptom_count = sum([
            pain, washedout_feeling, headache, sore_throat,
            breathless, cough, vomiting, diarrhea,
            taste_disorder, olfactory_disorder
        ])

        # 要注意条件判定
        if body_temp >= 37.5 or symptom_count >= 5:
            # contact_logに同じcheck_healthIDかつcontacted_reason=1の連絡ログがないか
            cur.execute("""
                SELECT contact_logID FROM contact_log 
                WHERE check_healthID = %s AND contacted_reason = 1
            """, (check_health_id,))
            if not cur.fetchone():
                # 連絡ログを作成（last_contact_dateはまだNULL）
                insert_contact_sql = """
                    INSERT INTO contact_log (
                        check_healthID, activityID, suspensionID, userID,
                        contacted_reason, last_contact_date, lastupdate
                    ) VALUES (%s, NULL, NULL, %s, 1, NULL, %s)
                """
                cur.execute(insert_contact_sql, (check_health_id, user_id, dt_now))
                conn.commit()

        cur.close()
        conn.close()
        return render_template("covid-19-check_health2.html", title="体調記録完了")

    except Exception as e:
        return f"エラーが発生しました: {e}"

# 行動記録
@app.route("/activity1")
def activity1():
    # ログインしていなければログインページへ
    if "username" not in session:
        return redirect(url_for("login"))
    
    # 行動記録記入フォームに移行
    return render_template("covid-19-activity1.html",
        title = "行動記録"
    )

# 行動記録受け取り・DB保存
@app.route("/activity2", methods=["POST"])
def activity2():
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = mysql.connector.connect(**dsn)
        cur = conn.cursor()

        # userID 取得
        cur.execute("SELECT userID FROM user_pass WHERE user_name = %s", (session["username"],))
        result = cur.fetchone()
        if not result:
            return "ユーザーが見つかりません"
        user_id = result[0]

        # フォームデータ取得
        went_date = request.form["went_date"]
        went_time = request.form["went_time"]
        return_time = request.form["return_time"]
        location = request.form["location"]
        move_method = request.form["move_method"]
        departure = request.form["departure"]
        arrival = request.form["arrival"]
        comp_NY = "comp_NY" in request.form
        comp_num = request.form.get("comp_num", "")
        sp_mention = request.form.get("sp_mention", "")
        dt_now = datetime.now()

        # 行動記録 INSERT
        insert_activity_sql = """
            INSERT INTO activity (
                userID, went_date, went_time, return_time, location,
                move_method, departure, arrival, comp_NY, comp_num, sp_mention, lastupdate
            ) VALUES (
                %s, %s, %s, %s, %s,
                %s, %s, %s, %s, %s, %s, %s
            )
        """
        cur.execute(insert_activity_sql, (
            user_id, went_date, went_time, return_time, location,
            move_method, departure, arrival, int(comp_NY), comp_num, sp_mention, dt_now
        ))
        conn.commit()

        activity_id = cur.lastrowid

        # 未入力3日以上の判定は別途ロジックが必要ですが
        # ここでは例として行動記録があれば contact_log に未入力者連絡記録を入れない方が自然なので、
        # 逆に3日以上行動記録がないユーザーは別処理で登録すると良いです。
        # もし行動記録登録時に未入力者連絡記録を作るなら以下のようにする例。

        # 以下は例なので実際は「3日以上未入力」かは判定ロジックを別途実装してください。

        # 連絡記録の追加（例として、ここでは行動記録登録時は連絡記録は入れない想定）
        # 必要ならここにロジック追加

        cur.close()
        conn.close()

        return render_template("covid-19-activity2.html", title="行動記録完了")

    except Exception as e:
        return f"エラーが発生しました: {e}"
# 履歴
@app.route("/history1")
def history1():
    # ログインしていなければログインページへ
    if "username" not in session:
        return redirect(url_for("login"))
    
    # 履歴表示に移行
    return render_template("covid-19-history_select.html",
        title = "履歴選択"
    )

# 履歴の選択
@app.route("/history_select", methods=["GET", "POST"])
def history_select():
    # ログインしていなければログインページへ
    if "username" not in session:
        return redirect(url_for("login"))

    choice = request.form.get("history_type")
    if choice == "health":
        return redirect(url_for("health_history"))
    elif choice == "activity":
        return redirect(url_for("activity_history"))
    else:
        return "無効な選択です"

# 健康観察記録の参照
@app.route("/history/health")
def health_history():
    # ログインしていなければログインページへ
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = mysql.connector.connect(**dsn)
        cur = conn.cursor(dictionary=True)

        cur.execute("SELECT userID FROM user_pass WHERE user_name = %s", (session["username"],))
        user_id = cur.fetchone()["userID"]

        cur.execute("""
            SELECT input_date, am_pm, body_temp, pain, washedout_feeling, headache, sore_throat,
                   breathless, cough, vomiting, diarrhea, taste_disorder, olfactory_disorder
            FROM check_health
            WHERE userID = %s AND delflag = FALSE
            ORDER BY input_date DESC
        """, (user_id,))
        records = cur.fetchall()

        cur.close()
        conn.close()

        return render_template("covid-19-health_history.html", title="体調記録履歴", records=records)

    except Exception as e:
        return f"エラーが発生しました: {e}"

# 行動記録の参照
@app.route("/history/activity")
def activity_history():
    # ログインしていなければログインページへ
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = mysql.connector.connect(**dsn)
        cur = conn.cursor(dictionary=True)

        cur.execute("SELECT userID FROM user_pass WHERE user_name = %s", (session["username"],))
        user_id = cur.fetchone()["userID"]

        # SQL文
        cur.execute("""
            SELECT went_date, went_time, return_time, location, move_method, departure,
                   arrival, comp_NY, comp_num, sp_mention
            FROM activity
            WHERE userID = %s AND delflag = FALSE
            ORDER BY went_date DESC, went_time DESC
        """, (user_id,))
        records = cur.fetchall()

        cur.close()
        conn.close()

        return render_template("covid-19-activity_history.html", title="行動記録履歴", records=records)

    except Exception as e:
        return f"エラーが発生しました: {e}"

# 感染報告
@app.route("/report")
def report():
    # ログインしていなければログインページへ
    if "username" not in session:
        return redirect(url_for("login"))
    
    # 感染報告に移行
    return render_template("covid-19-history_select.html",
        title = "履歴選択"
    )

# 個人情報
@app.route("/a_gaku1")
def a_gaku1():
    if "username" not in session:
        return redirect(url_for("login"))

    try:
        conn = mysql.connector.connect(**dsn)
        cur = conn.cursor(dictionary=True)

        cur.execute("SELECT userID FROM user_pass WHERE user_name = %s", (session["username"],))
        user_id = cur.fetchone()["userID"]

        cur.execute("""
            SELECT affiliation, user_code, l_name, f_name, l_name_kana, f_name_kana,
                   gender, birthday, e_mail, return_home, post_num, prefecture,
                   city, area, phone, user_name, password
            FROM user_userfrom_userpass
            WHERE userID = %s
        """, (user_id,))
        records = cur.fetchall()

        #csvから直接パスワードを読み込む
        plain_password = get_plain_password_from_csv(session["username"])
        
        if records:
            records[0]["password"] = plain_password
        cur.close()
        conn.close()

        return render_template("covid-19-personal_information.html", title="個人情報", records=records)

    except Exception as e:
        return f"エラーが発生しました: {e}"

# 管理者用のセッション

# 未記載一覧と要注意者一覧
@app.route("/admin/attention")
def admin_attention_list():
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    insert_missing_entry_contacts()  # contact_logへの未記載者自動登録

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    now = datetime.now()

    # 未記載者一覧（連絡がない or 連絡から3日以内）
    cur.execute("""
        SELECT 
            m.userID,
            m.user_code,
            m.l_name,
            m.f_name,
            m.email,
            m.phone,
            GREATEST(
                IFNULL(m.last_health_date, DATE('1900-01-01')),
                IFNULL(m.last_activity_date, DATE('1900-01-01'))
            ) AS last_input_date,
            cl.last_contact_date
        FROM missing_entry_user m
        LEFT JOIN contact_log cl
        ON m.userID = cl.userID AND cl.contacted_reason = 0
        WHERE cl.last_contact_date IS NULL
        OR DATEDIFF(CURDATE(), cl.last_contact_date) <= 3
    """)
    missing_users = cur.fetchall()

    # 要注意者一覧（連絡がない or 連絡から3日以内）
    cur.execute("""
        SELECT 
            vsc.userID,
            u.user_code,
            u.l_name,
            u.f_name,
            u.e_mail AS email,
            uf.phone AS phone,
            vsc.input_date,
            vsc.last_contact_date
        FROM view_symptomatic_contact vsc
        JOIN user u ON vsc.userID = u.userID
        LEFT JOIN user_from uf ON u.userID = uf.userID AND uf.delflag = FALSE
        WHERE vsc.last_contact_date IS NULL
        OR DATEDIFF(CURDATE(), vsc.last_contact_date) <= 3
    """)
    symptomatic_users = cur.fetchall()

    # 出校停止者一覧（出校停止期間中、連絡がない or 連絡から3日以内）
    cur.execute("""
        SELECT
            s.userID,
            u.l_name,
            u.f_name,
            s.start_date,
            s.end_date,
            cl.last_contact_date
        FROM suspension s
        JOIN user u ON s.userID = u.userID
        LEFT JOIN contact_log cl
          ON s.userID = cl.userID AND cl.contacted_reason = 2
        WHERE CURDATE() BETWEEN s.start_date AND s.end_date
          AND (cl.last_contact_date IS NULL OR DATEDIFF(CURDATE(), cl.last_contact_date) <= 3)
    """)
    suspension_users = cur.fetchall()

    cur.close()
    conn.close()

    return render_template(
        "admin_attention.html",
        title="要注意者・未記載者一覧",
        missing_users=missing_users,
        symptomatic_users=symptomatic_users,
        suspension_users=suspension_users
    )

from datetime import datetime

# 連絡状況の反映
@app.route("/admin/attention/update", methods=["POST"])
def update_contact_status():
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    # フォームから送られてきた各カテゴリの連絡済みユーザーIDリストを取得
    contacted_missing = set(request.form.getlist("contacted_missing"))
    contacted_symptomatic = set(request.form.getlist("contacted_symptomatic"))
    contacted_suspension = set(request.form.getlist("contacted_suspension"))

    now = datetime.now()

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(buffered=True)

    # 共通関数：contact_logテーブルの連絡済み更新・登録
    def update_contact(user_id, reason):
        cur.execute("""
            SELECT contact_logID FROM contact_log
            WHERE userID = %s AND contacted_reason = %s
        """, (user_id, reason))
        row = cur.fetchone()

        if row:
            contact_log_id = row[0]
            # 無条件で更新
            cur.execute("""
                UPDATE contact_log
                SET last_contact_date = %s, lastupdate = %s
                WHERE contact_logID = %s
            """, (now.date(), now, contact_log_id))
        else:
            cur.execute("""
                INSERT INTO contact_log (
                    userID, check_healthID, activityID, suspensionID,
                    contacted_reason, last_contact_date, lastupdate
                ) VALUES (%s, NULL, NULL, NULL, %s, %s, %s)
            """, (user_id, reason, now.date(), now))

    # 未記載者 contacted_reason = 0
    for user_id in contacted_missing:
        update_contact(user_id, 0)

    # 要注意者 contacted_reason = 1
    for user_id in contacted_symptomatic:
        update_contact(user_id, 1)

    # 出校停止者 contacted_reason = 2
    for user_id in contacted_suspension:
        update_contact(user_id, 2)

    conn.commit()
    cur.close()
    conn.close()

    flash("連絡状況を更新しました。")
    return redirect(url_for("admin_attention_list"))

# 全員の入力状況を確認
@app.route("/admin/attention/all")
def admin_all_status():
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    cur.execute("SELECT * FROM missing_entry_user")
    all_status = cur.fetchall()

    today = date.today()
    for row in all_status:
        row["missing_health_days"] = (today - row["last_health_date"]).days if row["last_health_date"] else None
        row["missing_activity_days"] = (today - row["last_activity_date"]).days if row["last_activity_date"] else None

    cur.close()
    conn.close()

    return render_template("admin_all_status.html", title="全ユーザー記録状況", users=all_status)

# 体調記録と行動記録の検索選択
@app.route("/admin/select", methods=["GET", "POST"])
def admin_select():
    # 管理者ログイン確認
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    # 検索項目の選択
    if request.method == "POST":
        choice = request.form.get("admin_search_type")
        if choice == "health":
            return redirect(url_for("admin_health_search"))  # 体調記録検索ページへ
        elif choice == "activity":
            return redirect(url_for("admin_activity_search"))  # 行動記録検索ページへ
        
        else:
            return "無効な選択です"
    
    return render_template("admin_select_search.html", title="検索対象の選択")

# 体調記録の検索
@app.route("/admin/search/health", methods=["GET", "POST"])
def admin_health_search():
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    # 体調記録選択画面を表示
    if request.method == "GET":
        return render_template("admin_health_search.html", title="体調記録の検索")

    # POST処理
    health_start = request.form.get("health_start_date")
    health_end = request.form.get("health_end_date")
    symptoms = request.form.getlist("symptoms")
    join_condition = request.form.get("join_condition", "AND").upper()

    health_conditions = []
    health_params = []

    # 日付条件
    if health_start:
        health_conditions.append("input_date >= %s")
        health_params.append(health_start)
    if health_end:
        health_conditions.append("input_date <= %s")
        health_params.append(health_end)

    # 症状の条件
    if symptoms:
        symptom_clauses = [f"{sym} = TRUE" for sym in symptoms]
        if join_condition == "AND":
            health_conditions.extend(symptom_clauses)
        else:
            health_conditions.append("(" + " OR ".join(symptom_clauses) + ")")

    # フォームから取得
    delflag_choice = request.form.get("delflag", "false")

    # delflag 条件の追加
    if delflag_choice == "false":
        health_conditions.insert(0, "delflag = FALSE")
    elif delflag_choice == "true":
        health_conditions.insert(0, "delflag = TRUE")
    # "all" の場合は条件に追加しない

    health_where = " AND ".join(health_conditions) if health_conditions else "1"

    # ビューを使用
    sql = f"""
        SELECT * FROM check_health_user
        WHERE ({health_where})
        ORDER BY input_date DESC, am_pm
    """

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)
    cur.execute(sql, health_params)
    results = cur.fetchall()
    cur.close()
    conn.close()

    return render_template(
        "admin_health_results.html",
        title="体調記録検索結果",
        health_results=results,
        activity_results=[],
        join_condition=join_condition
        )

# 行動記録の検索
@app.route("/admin/activity/search", methods=["GET", "POST"])
def admin_activity_search():
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))
    
    # 検索条件入力画面を表示
    if request.method == "GET":
        return render_template("admin_activity_search.html", title="行動記録の検索")

    start_date = request.form.get("activity_start_date")
    end_date = request.form.get("activity_end_date")
    location = request.form.get("location")
    move_method = request.form.get("move_method")
    join_condition = request.form.get("join_condition", "AND")
    delflag = request.form.get("delflag", "false")  # 未削除のみ

    # 検索条件
    conditions = []
    values = []

    if start_date:
        conditions.append("went_date >= %s")
        values.append(start_date)

    if end_date:
        conditions.append("went_date <= %s")
        values.append(end_date)

    if location:
        conditions.append("location LIKE %s")
        values.append(f"%{location}%")

    if move_method:
        conditions.append("move_method LIKE %s")
        values.append(f"%{move_method}%")

    # 削除フラグ処理
    if delflag == "false":
        conditions.append("delflag = 0")
    elif delflag == "true":
        conditions.append("delflag = 1")

    where_clause = ""
    if conditions:
        where_clause = "WHERE " + f" {join_condition} ".join(conditions)

    sql = f"SELECT * FROM activity_user {where_clause} ORDER BY went_date DESC"

    # DB接続と実行
    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)
    cur.execute(sql, tuple(values))
    activity_results = cur.fetchall()
    cur.close()
    conn.close()

    return render_template("admin_activity_results.html", title="行動記録検索結果", activity_results=activity_results)

# 体調記録編集
@app.route("/admin/health/edit/<int:check_healthID>", methods=["GET", "POST"])
def edit_health_record(check_healthID):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    if request.method == "POST":
        # フォームから削除フラグを取得（checkboxは存在しないときNoneになる）
        delflag = request.form.get("delflag") == "on"

        # 更新処理
        sql = "UPDATE check_health SET delflag = %s, lastupdate = NOW() WHERE check_healthID = %s"
        cur.execute(sql, (delflag, check_healthID))
        conn.commit()
        cur.close()
        conn.close()

        message = "削除フラグを更新しました。"
        return render_template("admin_health_message.html", message=message)

    # GET: 対象レコード取得
    sql = "SELECT * FROM check_health_user WHERE check_healthID = %s"
    cur.execute(sql, (check_healthID,))
    record = cur.fetchone()
    cur.close()
    conn.close()

    if not record:
        flash("該当する体調記録が見つかりません。")
        return redirect(url_for("admin_health_search"))

    return render_template("admin_edit_health_record.html", title="体調記録編集", record=record)

# 行動記録編集
@app.route("/admin/activity/edit/<int:activityID>", methods=["GET", "POST"])
def edit_activity_record(activityID):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    if request.method == "POST":
        # フォームから削除フラグを取得（チェックなし＝None）
        delflag = request.form.get("delflag") == "on"

        # 削除フラグだけ更新（必要なら他項目も追加可能）
        sql = "UPDATE activity SET delflag = %s, lastupdate = NOW() WHERE activityID = %s"
        cur.execute(sql, (delflag, activityID))
        conn.commit()
        cur.close()
        conn.close()

        message = "削除フラグを更新しました。"
        return render_template("admin_activity_message.html", message=message)

    # GET：対象レコード取得（ビュー名はあなたの定義に合わせて）
    sql = "SELECT * FROM activity_user WHERE activityID = %s"
    cur.execute(sql, (activityID,))
    record = cur.fetchone()
    cur.close()
    conn.close()

    if not record:
        flash("該当する行動記録が見つかりません。")
        return redirect(url_for("activity_history"))

    return render_template("admin_edit_activity_record.html", title="行動記録の検索", record=record)

# ユーザー情報の編集
@app.route("/admin/user")
def admin_user():
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))
    # 管理者専用の編集ページを表示
    return render_template("admin_user.html", title="ユーザー情報の編集")

# ユーザーの一覧表示
@app.route("/admin/user/list")
def user_list():
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM user")
    users = cur.fetchall()
    cur.close()
    conn.close()

    return render_template("admin_user_list.html", title="ユーザー一覧", users=users)

# 編集選択画面
@app.route("/admin/user/edit/<int:user_id>")
def edit_user_menu(user_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))
    return render_template("admin_user_edit_menu.html", user_id=user_id)

# 出校停止の一覧
@app.route("/admin/user/<int:user_id>/suspension")
def user_suspension_list(user_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT * FROM suspension
        WHERE userID = %s AND delflag = FALSE
        ORDER BY start_date DESC
    """, (user_id,))
    suspensions = cur.fetchall()
    cur.close()
    conn.close()

    return render_template("admin_user_suspension_list.html", title="出校停止情報", suspensions=suspensions, user_id=user_id)

# 出校停止の新規追加
@app.route("/admin/user/<int:user_id>/suspension/add", methods=["GET", "POST"])
def add_user_suspension(user_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    if request.method == "POST":
        start_date = request.form.get("start_date")
        end_date = request.form.get("end_date")
        reason = request.form.get("reason")
        institution_name = request.form.get("institution_name")
        doctor_name = request.form.get("doctor_name")
        status = int(request.form.get("status"))
        mention = request.form.get("mention")

        conn = mysql.connector.connect(**dsn)
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO suspension (
                userID, susp_school, start_date, end_date,
                reason, institution_name, doctor_name,
                status, mention, delflag, lastupdate
            ) VALUES (%s, TRUE, %s, %s, %s, %s, %s, %s, %s, FALSE, NOW())
        """, (user_id, start_date, end_date, reason, institution_name, doctor_name, status, mention))
        conn.commit()
        cur.close()
        conn.close()

        return redirect(url_for("user_suspension_list", user_id=user_id))

    return render_template("admin_add_user_suspension.html", title="出校停止追加", user_id=user_id)

# 基本情報の変更
@app.route("/admin/user/edit_basic/<int:user_id>", methods=["GET", "POST"])
def edit_user_basic(user_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    if request.method == "POST":
        # ユーザーを削除するかどうか
        if request.form.get("delete_user") == "true":
            # 論理削除（削除フラグをTrueに）
            sql = "UPDATE user SET delflag = TRUE, lastupdate = NOW() WHERE userID = %s"
            cur.execute(sql, (user_id,))
            conn.commit()
            cur.close()
            conn.close()
            return render_template("admin_edit_message.html", message="ユーザーを削除しました。")
        
        l_name = request.form.get("l_name")
        f_name = request.form.get("f_name")
        l_name_kana = request.form.get("l_name_kana")
        f_name_kana = request.form.get("f_name_kana")
        affiliation = request.form.get("affiliation")
        gender = int(request.form.get("gender"))
        birthday = request.form.get("birthday")

        sql = """
            UPDATE user
            SET l_name=%s, f_name=%s,
                l_name_kana=%s, f_name_kana=%s,
                affiliation=%s, gender=%s,
                birthday=%s, lastupdate=NOW()
            WHERE userID = %s
        """
        cur.execute(sql, (l_name, f_name, l_name_kana, f_name_kana,
                          affiliation, gender, birthday, user_id))
        conn.commit()
        cur.close()
        conn.close()
        return render_template("admin_edit_message.html", message="基本情報を更新しました。")

    # GET: ユーザー情報の取得
    cur.execute("SELECT * FROM user WHERE userID = %s", (user_id,))
    user = cur.fetchone()
    cur.close()
    conn.close()

    return render_template("admin_edit_user_basic.html", title="基本情報の編集", user=user)

# 住所・連絡先の変更（複数件一覧）
@app.route("/admin/user/edit_address/<int:user_id>", methods=["GET"])
def edit_user_address_list(user_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM user_from WHERE userID = %s AND delflag = 0 ORDER BY return_home DESC, user_fromID", (user_id,))
    addresses = cur.fetchall()
    cur.close()
    conn.close()

    return render_template("admin_edit_user_address_list.html", title="住所・連絡先一覧", addresses=addresses, user_id=user_id)

# 住所・連絡先の変更
@app.route("/admin/user/edit_address_detail/<int:user_from_id>", methods=["GET", "POST"])
def edit_user_address_detail(user_from_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    if request.method == "POST":
        return_home = request.form.get("return_home") == "on"
        post_num = request.form.get("post_num")
        prefecture = request.form.get("prefecture")
        city = request.form.get("city")
        area = request.form.get("area")
        phone = request.form.get("phone")
        e_mail = request.form.get("e_mail")

        sql = """
            UPDATE user_from SET
                return_home=%s, post_num=%s, prefecture=%s, city=%s,
                area=%s, phone=%s, e_mail=%s, lastupdate=NOW()
            WHERE user_fromID=%s
        """
        cur.execute(sql, (return_home, post_num, prefecture, city, area, phone, e_mail, user_from_id))

        conn.commit()
        cur.close()
        conn.close()
        return render_template("admin_edit_message.html", message="住所・連絡先を更新しました。")

    else:
        cur.execute("SELECT * FROM user_from WHERE user_fromID = %s", (user_from_id,))
        address = cur.fetchone()
        cur.close()
        conn.close()

        if address is None:
            return render_template("admin_edit_message.html", message="指定の住所情報が見つかりません。")

        return render_template("admin_edit_user_address_detail.html", title="住所・連絡先編集", address=address)

# パスワードの変更
@app.route("/admin/user/edit_password/<int:user_id>", methods=["GET", "POST"])
def edit_user_password(user_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    if request.method == "POST":
        new_password = request.form.get("new_password")

        # パスワードはハッシュ化して保存
        hashed_pw = generate_password_hash(new_password)

        conn = mysql.connector.connect(**dsn)
        cur = conn.cursor()
        sql = "UPDATE user_pass SET password=%s, lastupdate=NOW() WHERE userID=%s"
        cur.execute(sql, (hashed_pw, user_id))
        conn.commit()
        cur.close()
        conn.close()

        return render_template("admin_edit_message.html", message="パスワードを変更しました。")

    return render_template("admin_edit_user_password.html", title="パスワードの変更", user_id=user_id)

# ログイン情報編集
@app.route("/admin/user/edit_login/<int:user_id>", methods=["GET", "POST"])
def edit_user_login(user_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    # 編集対象ユーザーのログイン情報取得
    cur.execute("SELECT * FROM user_pass WHERE userID = %s", (user_id,))
    user_pass = cur.fetchone()

    # 現在ログイン中の管理者が自分自身の情報を編集しようとしているかどうか
    is_self = (session.get("user_id") == user_id)

    if request.method == "POST":
        user_name = request.form.get("user_name")

        # 管理者自身はpermissionを変更できない
        if is_self:
            permission = user_pass["permission"]
        else:
            permission = request.form.get("permission")

        sql = """
            UPDATE user_pass
            SET user_name = %s, permission = %s, lastupdate = NOW()
            WHERE userID = %s
        """
        cur.execute(sql, (user_name, permission, user_id))
        conn.commit()
        cur.close()
        conn.close()

        return render_template("admin_edit_message.html", message="ログイン情報・権限を更新しました。")

    cur.close()
    conn.close()

    return render_template(
        "admin_edit_user_login.html",
        title="ログイン情報・権限の変更",
        user_id=user_id,
        user_pass=user_pass,
        is_self=is_self
    )

# ユーザーの追加（csvファイルのアップロード）
@app.route('/admin/user/upload_csv', methods=['GET', 'POST'])
def upload_user_csv():
    if 'username' not in session or session.get('permission') != 1:
        return redirect(url_for('login'))

    # DB接続して次の userID を取得
    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor()
    cur.execute("SELECT COALESCE(MAX(userID), 0) + 1 FROM user")
    next_user_id = cur.fetchone()[0]
    cur.close()
    conn.close()

    if request.method == 'POST':
        files = {
            'user_csv': request.files.get('user_csv'),
            'user_from_csv': request.files.get('user_from_csv'),
            'user_pass_csv': request.files.get('user_pass_csv')
        }

        # ファイルの存在チェック
        for key, file in files.items():
            if file is None or file.filename == '':
                flash(f'{key}がアップロードされていません。')
                return redirect(request.url)
            if not allowed_file(file.filename):
                flash(f'{file.filename}はCSVファイルではありません。')
                return redirect(request.url)

        # 一時保存
        saved_paths = {}
        for key, file in files.items():
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            saved_paths[key] = filepath

        # DB接続
        conn = mysql.connector.connect(**dsn)
        cur = conn.cursor()

        dt_now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # user.csv の挿入
        df_user = pd.read_csv(saved_paths['user_csv'])
        for _, row in df_user.iterrows():
            sql = """
                INSERT INTO user
                (schoolID, affiliation, user_code, l_name, f_name, l_name_kana, f_name_kana,
                 gender, birthday, e_mail, lastupdate)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            cur.execute(sql, (
                row['schoolID'], row['affiliation'], row['user_code'], row['l_name'], row['f_name'],
                row['l_name_kana'], row['f_name_kana'], row['gender'], row['birthday'], row['e_mail'], dt_now
            ))

        # user_from.csv の挿入
        df_user_from = pd.read_csv(saved_paths['user_from_csv'])
        for _, row in df_user_from.iterrows():
            sql = """
                INSERT INTO user_from
                (userID, return_home, post_num, prefecture, city, area, phone, lastupdate)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            cur.execute(sql, (
                row['userID'], row['return_home'], row['post_num'], row['prefecture'],
                row['city'], row['area'], row['phone'], dt_now
            ))

        # user_pass.csv の挿入（パスワードはハッシュ化）
        df_user_pass = pd.read_csv(saved_paths['user_pass_csv'])
        for _, row in df_user_pass.iterrows():
            hashed_pw = bcrypt.generate_password_hash(str(row['password'])).decode('utf-8')
            sql = """
                INSERT INTO user_pass
                (userID, permission, user_name, password, lastupdate)
                VALUES (%s, %s, %s, %s, %s)
            """
            cur.execute(sql, (
                row['userID'], row['permission'], row['user_name'], hashed_pw, dt_now
            ))

        conn.commit()
        cur.close()
        conn.close()

        flash('CSVファイルからユーザー情報を登録しました。')
        return redirect(url_for('user_list'))

    # GET時はアップロードフォーム表示
    return render_template('admin_user_upload_csv.html', title='CSVアップロード', next_user_id=next_user_id)

# 学校一覧表示（学校編集または課一覧に遷移）
@app.route('/admin/school/list')
def school_list():
    if 'username' not in session or session.get('permission') != 1:
        return redirect(url_for('login'))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT * FROM school ORDER BY school_name")
    schools = cur.fetchall()
    cur.close()
    conn.close()

    return render_template('admin_school_list.html', title='学校一覧', schools=schools)

# 課の一覧表示（school_idがある場合は絞り込み）
@app.route("/admin/department/list")
def department_list():
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    school_id = request.args.get("school_id", type=int)

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    if school_id:
        sql = """
            SELECT d.*, s.school_name
            FROM department d
            JOIN school s ON d.schoolID = s.schoolID
            WHERE d.delflag = FALSE AND d.schoolID = %s
            ORDER BY d.department_name
        """
        cur.execute(sql, (school_id,))
    else:
        sql = """
            SELECT d.*, s.school_name
            FROM department d
            JOIN school s ON d.schoolID = s.schoolID
            WHERE d.delflag = FALSE
            ORDER BY d.schoolID, d.department_name
        """
        cur.execute(sql)

    departments = cur.fetchall()

    school = None
    if school_id:
        cur.execute("SELECT * FROM school WHERE schoolID = %s", (school_id,))
        school = cur.fetchone()

    cur.close()
    conn.close()

    return render_template("admin_department_list.html", title="課 一覧", departments=departments, school=school)

# 学校情報の編集
@app.route('/admin/school/edit/<int:school_id>', methods=['GET', 'POST'])
def edit_school(school_id):
    if 'username' not in session or session.get('permission') != 1:
        return redirect(url_for('login'))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    if request.method == 'POST':
        school_name = request.form.get('school_name')
        post_num = request.form.get('post_num')
        prefecture = request.form.get('prefecture')
        city = request.form.get('city')
        area = request.form.get('area')

        sql = '''
            UPDATE school SET
                school_name=%s,
                post_num=%s,
                prefecture=%s,
                city=%s,
                area=%s,
                lastupdate=NOW()
            WHERE schoolID=%s
        '''
        cur.execute(sql, (school_name, post_num, prefecture, city, area, school_id))
        conn.commit()
        cur.close()
        conn.close()
        return render_template("admin_edit_message.html", message="学校情報を更新しました。")

    cur.execute("SELECT * FROM school WHERE schoolID = %s", (school_id,))
    school = cur.fetchone()
    cur.close()
    conn.close()

    return render_template("admin_edit_school.html", title="学校情報の編集", school=school)

# 課情報の編集
@app.route("/admin/department/edit/<int:office_id>", methods=["GET", "POST"])
def edit_department(office_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    if request.method == "POST":
        department_name = request.form.get("department_name")
        phone = request.form.get("phone")
        sql = """
            UPDATE department
            SET department_name = %s, phone = %s, lastupdate = NOW()
            WHERE officeID = %s
        """
        cur.execute(sql, (department_name, phone, office_id))
        conn.commit()
        cur.close()
        conn.close()
        return redirect(url_for("department_list"))

    cur.execute("""
        SELECT d.*, s.school_name
        FROM department d
        JOIN school s ON d.schoolID = s.schoolID
        WHERE d.officeID = %s
    """, (office_id,))
    department = cur.fetchone()

    cur.close()
    conn.close()

    return render_template("admin_edit_department.html", title="課の編集", department=department)

# 課の新規追加
@app.route("/admin/department/add", methods=["GET", "POST"])
def add_department():
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor(dictionary=True)

    if request.method == "POST":
        schoolID = request.form.get("schoolID")
        department_name = request.form.get("department_name")
        phone = request.form.get("phone")
        sql = """
            INSERT INTO department (schoolID, department_name, phone, lastupdate)
            VALUES (%s, %s, %s, NOW())
        """
        cur.execute(sql, (schoolID, department_name, phone))
        conn.commit()
        cur.close()
        conn.close()
        return redirect(url_for("department_list"))

    cur.execute("SELECT schoolID, school_name FROM school ORDER BY school_name")
    schools = cur.fetchall()
    cur.close()
    conn.close()

    return render_template("admin_add_department.html", title="課の追加", schools=schools)

# 課の削除（論理削除）
@app.route("/admin/department/delete/<int:office_id>", methods=["POST"])
def delete_department(office_id):
    if "username" not in session or session.get("permission") != 1:
        return redirect(url_for("login"))

    conn = mysql.connector.connect(**dsn)
    cur = conn.cursor()
    sql = "UPDATE department SET delflag = TRUE, lastupdate = NOW() WHERE officeID = %s"
    cur.execute(sql, (office_id,))
    conn.commit()
    cur.close()
    conn.close()

    return redirect(url_for("department_list"))


if __name__ == '__main__':
    app.run(host="localhost", port=5000, debug=True)